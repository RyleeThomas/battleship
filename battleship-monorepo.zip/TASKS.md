# Developer Task Breakdown

## Milestone 0 — Repo & Foundations
- [ ] Initialize monorepo (pnpm workspaces), set up `apps/web`, `apps/functions`, `packages/engine`.
- [ ] Configure linting, Prettier, TypeScript strict across packages.
- [ ] Add basic CI: install, typecheck, build for web and engine.

## Milestone 1 — Game Engine (Deterministic Core)
- [ ] Implement board/ship types and placement with bounds/overlap checks.
- [ ] Apply move logic and results (`hit|miss|sink`) with unit tests.
- [ ] Add property-based tests (fast-check) for invariants (later).
- [ ] Expose AI heuristic (hunt/target + parity scan).

## Milestone 2 — Web App (2D UI First)
- [ ] Build 10x10 grid UI with responsive layout and keyboard support.
- [ ] Client state: local board setup, move submission, optimistic updates.
- [ ] Auth (Supabase Auth: email/password + magic link).

## Milestone 3 — Backend API (Edge Functions)
- [ ] `POST /move` edge function: validate auth, turn order, duplicate moves.
- [ ] Persist move to Postgres (`moves`), update `matches.current_turn` in tx.
- [ ] Emit realtime broadcast on successful move.

## Milestone 4 — Realtime & Presence
- [ ] Subscribe to `match:{id}` channel; fan out moves to both clients.
- [ ] Presence (who’s online, typing/placing), reconnect handling.
- [ ] Spectator mode (delayed fog-of-war) scaffold.

## Milestone 5 — Async Play & Notifications
- [ ] Web Push (OneSignal or VAPID): prompt, subscribe, store endpoints.
- [ ] Notification service path: on new move, notify opponent if offline.
- [ ] Scheduled nudges (Supabase scheduler or cron) for stale matches.

## Milestone 6 — Matchmaking & Ranking
- [ ] Quick Match queue; start matches when two clients are waiting.
- [ ] ELO/Glicko-2 updates on match end; seasonal leaderboard.
- [ ] Basic anti-cheat (server-authoritative checks; no client board leakage).

## Milestone 7 — AI/Bot Opponent
- [ ] Bot micro (can be a separate channel in Edge Functions) that chooses moves via engine AI.
- [ ] Difficulty levels (pure hunt vs hunt+target vs probability heatmap).

## Milestone 8 — Polish & Accessibility
- [ ] Animations for hits/sinks, subtle sounds (opt-out).
- [ ] Keyboard nav + screen reader labels for the board.
- [ ] Settings: board size variants, theme (light/dark/“navy”).

## Milestone 9 — Observability & QA
- [ ] Client metrics (CLS, FID) + custom events (match start/end).
- [ ] Logging + tracing for functions; error boundary screens.
- [ ] E2E tests with Playwright (PvP flow + resume after reload).
- [ ] Load testing (optional) with k6 on the move endpoint.

---
## Nice-to-haves
- [ ] Tournaments with Swiss rounds.
- [ ] Replay viewer with turn scrubber and share links.
- [ ] 3D shot replay mode (Three.js) toggle (keep 2D default).