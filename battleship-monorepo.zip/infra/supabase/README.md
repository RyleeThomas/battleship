# Supabase Infra

- `schema.sql` — run in SQL Editor to create starter tables.
- Add RLS policies for `insert`/`update` to restrict to match participants.
- Consider Postgres functions for server-side validations.