# Supabase Edge Functions

- `move/` — validates a turn and writes to DB (stubbed). Deploy with `supabase functions deploy move`.
- Add `notify/` later to fan out web push (or use database triggers + supabase realtime).